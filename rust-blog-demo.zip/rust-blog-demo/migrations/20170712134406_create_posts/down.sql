DROP TABLE posts;
