ALTER TABLE posts DROP CONSTRAINT posts_user_id_fkey;
