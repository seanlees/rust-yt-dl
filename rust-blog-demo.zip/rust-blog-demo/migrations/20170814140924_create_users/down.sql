DROP TABLE users;
